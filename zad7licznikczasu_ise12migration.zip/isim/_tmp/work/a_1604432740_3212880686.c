/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/zad6wyswietlaczlab/led_7_input_data1.vhd";
extern char *IEEE_P_2592010699;

unsigned char p_2592010699_sub_1690584930_2592010699(char *, unsigned char );
unsigned char p_2592010699_sub_1744673427_2592010699(char *, char *, unsigned int , unsigned int );


static void work_a_1604432740_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    int t11;
    char *t12;
    int t14;
    char *t15;
    int t17;
    char *t18;
    int t20;
    char *t21;
    int t23;
    char *t24;
    int t26;
    char *t27;
    int t29;
    char *t30;
    int t32;
    char *t33;
    int t35;
    char *t36;
    int t38;
    char *t39;
    int t41;
    char *t42;
    int t44;
    char *t45;
    int t47;
    char *t48;
    int t50;
    char *t51;
    int t53;
    char *t54;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;

LAB0:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t3 = (7 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 3364);
    t8 = xsi_mem_cmp(t6, t1, 4U);
    if (t8 == 1)
        goto LAB3;

LAB20:    t9 = (t0 + 3368);
    t11 = xsi_mem_cmp(t9, t1, 4U);
    if (t11 == 1)
        goto LAB4;

LAB21:    t12 = (t0 + 3372);
    t14 = xsi_mem_cmp(t12, t1, 4U);
    if (t14 == 1)
        goto LAB5;

LAB22:    t15 = (t0 + 3376);
    t17 = xsi_mem_cmp(t15, t1, 4U);
    if (t17 == 1)
        goto LAB6;

LAB23:    t18 = (t0 + 3380);
    t20 = xsi_mem_cmp(t18, t1, 4U);
    if (t20 == 1)
        goto LAB7;

LAB24:    t21 = (t0 + 3384);
    t23 = xsi_mem_cmp(t21, t1, 4U);
    if (t23 == 1)
        goto LAB8;

LAB25:    t24 = (t0 + 3388);
    t26 = xsi_mem_cmp(t24, t1, 4U);
    if (t26 == 1)
        goto LAB9;

LAB26:    t27 = (t0 + 3392);
    t29 = xsi_mem_cmp(t27, t1, 4U);
    if (t29 == 1)
        goto LAB10;

LAB27:    t30 = (t0 + 3396);
    t32 = xsi_mem_cmp(t30, t1, 4U);
    if (t32 == 1)
        goto LAB11;

LAB28:    t33 = (t0 + 3400);
    t35 = xsi_mem_cmp(t33, t1, 4U);
    if (t35 == 1)
        goto LAB12;

LAB29:    t36 = (t0 + 3404);
    t38 = xsi_mem_cmp(t36, t1, 4U);
    if (t38 == 1)
        goto LAB13;

LAB30:    t39 = (t0 + 3408);
    t41 = xsi_mem_cmp(t39, t1, 4U);
    if (t41 == 1)
        goto LAB14;

LAB31:    t42 = (t0 + 3412);
    t44 = xsi_mem_cmp(t42, t1, 4U);
    if (t44 == 1)
        goto LAB15;

LAB32:    t45 = (t0 + 3416);
    t47 = xsi_mem_cmp(t45, t1, 4U);
    if (t47 == 1)
        goto LAB16;

LAB33:    t48 = (t0 + 3420);
    t50 = xsi_mem_cmp(t48, t1, 4U);
    if (t50 == 1)
        goto LAB17;

LAB34:    t51 = (t0 + 3424);
    t53 = xsi_mem_cmp(t51, t1, 4U);
    if (t53 == 1)
        goto LAB18;

LAB35:
LAB19:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 3540);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_fast(t6);

LAB2:    t1 = (t0 + 1992);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(51, ng0);
    t54 = (t0 + 3428);
    t56 = (t0 + 2044);
    t57 = (t56 + 32U);
    t58 = *((char **)t57);
    t59 = (t58 + 40U);
    t60 = *((char **)t59);
    memcpy(t60, t54, 7U);
    xsi_driver_first_trans_delta(t56, 0U, 7U, 0LL);
    goto LAB2;

LAB4:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 3435);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB5:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 3442);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB6:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 3449);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB7:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 3456);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB8:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 3463);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB9:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 3470);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB10:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 3477);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB11:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 3484);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB12:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 3491);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB13:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 3498);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB14:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 3505);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB15:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 3512);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB16:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 3519);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB17:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3526);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB18:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 3533);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t9 = *((char **)t7);
    t10 = (t9 + 40U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 7U);
    xsi_driver_first_trans_delta(t6, 0U, 7U, 0LL);
    goto LAB2;

LAB36:;
}

static void work_a_1604432740_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned char t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;

LAB0:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 636U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 528U);
    t3 = p_2592010699_sub_1744673427_2592010699(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 2000);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(74, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t5 = t1;
    memset(t5, (unsigned char)3, 32U);
    t6 = (t0 + 2080);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 32U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(75, ng0);
    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    memset(t2, (unsigned char)2, 4U);
    t5 = (t0 + 2116);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast(t5);
    goto LAB3;

LAB5:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 724U);
    t5 = *((char **)t2);
    t2 = (t0 + 2116);
    t6 = (t2 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(79, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t11 = (0 - 3);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t4 = *((unsigned char *)t1);
    t15 = (t4 == (unsigned char)3);
    if (t15 == 1)
        goto LAB10;

LAB11:    t3 = (unsigned char)0;

LAB12:    if (t3 != 0)
        goto LAB7;

LAB9:    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t11 = (1 - 3);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t4 = *((unsigned char *)t1);
    t15 = (t4 == (unsigned char)3);
    if (t15 == 1)
        goto LAB15;

LAB16:    t3 = (unsigned char)0;

LAB17:    if (t3 != 0)
        goto LAB13;

LAB14:    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t11 = (2 - 3);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t4 = *((unsigned char *)t1);
    t15 = (t4 == (unsigned char)3);
    if (t15 == 1)
        goto LAB20;

LAB21:    t3 = (unsigned char)0;

LAB22:    if (t3 != 0)
        goto LAB18;

LAB19:    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t11 = (3 - 3);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t4 = *((unsigned char *)t1);
    t15 = (t4 == (unsigned char)3);
    if (t15 == 1)
        goto LAB25;

LAB26:    t3 = (unsigned char)0;

LAB27:    if (t3 != 0)
        goto LAB23;

LAB24:
LAB8:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t11 = (4 - 7);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t3);
    t5 = (t0 + 2080);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_delta(t5, 31U, 1, 0LL);
    xsi_set_current_line(89, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t11 = (5 - 7);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t3);
    t5 = (t0 + 2080);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_delta(t5, 23U, 1, 0LL);
    xsi_set_current_line(90, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t11 = (6 - 7);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t3);
    t5 = (t0 + 2080);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_delta(t5, 15U, 1, 0LL);
    xsi_set_current_line(91, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t11 = (7 - 7);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t1 = (t2 + t14);
    t3 = *((unsigned char *)t1);
    t4 = p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t3);
    t5 = (t0 + 2080);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_delta(t5, 7U, 1, 0LL);
    goto LAB3;

LAB7:    xsi_set_current_line(80, ng0);
    t7 = (t0 + 988U);
    t8 = *((char **)t7);
    t7 = (t0 + 2080);
    t9 = (t7 + 32U);
    t10 = *((char **)t9);
    t22 = (t10 + 40U);
    t23 = *((char **)t22);
    memcpy(t23, t8, 7U);
    xsi_driver_first_trans_delta(t7, 24U, 7U, 0LL);
    goto LAB8;

LAB10:    t5 = (t0 + 1076U);
    t6 = *((char **)t5);
    t16 = (0 - 3);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t5 = (t6 + t19);
    t20 = *((unsigned char *)t5);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB12;

LAB13:    xsi_set_current_line(82, ng0);
    t7 = (t0 + 988U);
    t8 = *((char **)t7);
    t7 = (t0 + 2080);
    t9 = (t7 + 32U);
    t10 = *((char **)t9);
    t22 = (t10 + 40U);
    t23 = *((char **)t22);
    memcpy(t23, t8, 7U);
    xsi_driver_first_trans_delta(t7, 16U, 7U, 0LL);
    goto LAB8;

LAB15:    t5 = (t0 + 1076U);
    t6 = *((char **)t5);
    t16 = (1 - 3);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t5 = (t6 + t19);
    t20 = *((unsigned char *)t5);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB17;

LAB18:    xsi_set_current_line(84, ng0);
    t7 = (t0 + 988U);
    t8 = *((char **)t7);
    t7 = (t0 + 2080);
    t9 = (t7 + 32U);
    t10 = *((char **)t9);
    t22 = (t10 + 40U);
    t23 = *((char **)t22);
    memcpy(t23, t8, 7U);
    xsi_driver_first_trans_delta(t7, 8U, 7U, 0LL);
    goto LAB8;

LAB20:    t5 = (t0 + 1076U);
    t6 = *((char **)t5);
    t16 = (2 - 3);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t5 = (t6 + t19);
    t20 = *((unsigned char *)t5);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB22;

LAB23:    xsi_set_current_line(86, ng0);
    t7 = (t0 + 988U);
    t8 = *((char **)t7);
    t7 = (t0 + 2080);
    t9 = (t7 + 32U);
    t10 = *((char **)t9);
    t22 = (t10 + 40U);
    t23 = *((char **)t22);
    memcpy(t23, t8, 7U);
    xsi_driver_first_trans_delta(t7, 0U, 7U, 0LL);
    goto LAB8;

LAB25:    t5 = (t0 + 1076U);
    t6 = *((char **)t5);
    t16 = (3 - 3);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t5 = (t6 + t19);
    t20 = *((unsigned char *)t5);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB27;

}


extern void work_a_1604432740_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1604432740_3212880686_p_0,(void *)work_a_1604432740_3212880686_p_1};
	xsi_register_didat("work_a_1604432740_3212880686", "isim/_tmp/work/a_1604432740_3212880686.didat");
	xsi_register_executes(pe);
}
